package com.thinkEasily.restapidemo.Controller;

import com.thinkEasily.restapidemo.model.CloudVendor;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/cloudvendor")

public class CloudApiServices {
    CloudVendor cloudVendor;
    @GetMapping("{vendorId}")
    public CloudVendor getCloudvendorDetails(String vendorId){

        return cloudVendor;
//                  // for get data cloud vendor
//                new CloudVendor("a1","Vendor1",
//                        "Address1","123456789 ");

    }

    @PostMapping
    public String ceateCloudVendorDetails(@RequestBody CloudVendor  cloudVendor){
           this.cloudVendor=cloudVendor;
           return "vendor created sucessfully";

    }

    // for updating the vendor

    @PutMapping
    public String updateCloudvendorDetails(){
        this.cloudVendor=cloudVendor;
        return"vendor Updated sucessfully";
    }

    // for deleting vendor
    @DeleteMapping("{vendorId}")
    public String deleteCloudvendorDetails(String vendorId){
        this.cloudVendor=null;
        return"vendor Deleted sucessfully";
    }




}
