package spring.testapi.service;

import org.springframework.beans.factory.annotation.Autowired;
import spring.testapi.Entity.Department;
import spring.testapi.repo.DepartmentRepo;

import java.util.List;

public interface DepartmentService {
    public Department saveDepartment(Department department);

   public List<Department> fetchDepartmentList();

}
